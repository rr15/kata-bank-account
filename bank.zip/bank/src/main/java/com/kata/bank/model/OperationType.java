package com.kata.bank.model;

public enum OperationType {
    DEPOSIT, WITHDRAWAL
}
