package com.kata.bank.service;

import com.kata.bank.model.User;

public interface UserService {
    User findById(Integer id);
}
